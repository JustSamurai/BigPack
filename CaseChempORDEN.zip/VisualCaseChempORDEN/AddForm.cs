﻿using Microsoft.SqlServer.Dts.ManagedConnections;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace VisualCaseChempORDEN.Resources
{
    public partial class AddForm : Form
    {
        public string Strconn;
        public SqlConnection conn;
        string query;
        public AddForm()
        {
            InitializeComponent();
            Strconn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            conn = new SqlConnection(Strconn);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                query = "INSERT INTO Material (Title, CountInPack, Unit, CountInStock, MinCount, Cost, [Image], MaterialTypeID) VALUES " +
                    "('" + tbMaterial.Text + "', '" + tbCountinPack.Text + "', '" + tbUnit.Text + "', '" + tbCountinCost.Text + "', '" + tbMIN.Text + "', '" + tbPrice.Text + "', '" + tbImage.Text + "', '" + tbTypeMaterial.Text + "')";
                SqlCommand cmd = new SqlCommand(query, conn);
                int rdn = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void AddForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            BolshaiaPacka bolshaiaPacka = new BolshaiaPacka();
            bolshaiaPacka.Show();
        }
    }
}
