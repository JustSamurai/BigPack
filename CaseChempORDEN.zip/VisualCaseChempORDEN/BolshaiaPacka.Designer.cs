﻿
namespace VisualCaseChempORDEN
{
    partial class BolshaiaPacka
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BolshaiaPacka));
            this.filtering = new System.Windows.Forms.ComboBox();
            this.Search1 = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGrid1 = new System.Windows.Forms.DataGridView();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSupplier = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnInStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataSet1 = new VisualCaseChempORDEN.DataSet1();
            this.dataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // filtering
            // 
            this.filtering.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.filtering.FormattingEnabled = true;
            this.filtering.Items.AddRange(new object[] {
            "Гранулы",
            "Краски",
            "Нитки"});
            this.filtering.Location = new System.Drawing.Point(396, 23);
            this.filtering.Name = "filtering";
            this.filtering.Size = new System.Drawing.Size(203, 21);
            this.filtering.TabIndex = 2;
            this.filtering.SelectedIndexChanged += new System.EventHandler(this.filtering_SelectedIndexChanged);
            // 
            // Search1
            // 
            this.Search1.Location = new System.Drawing.Point(16, 24);
            this.Search1.Name = "Search1";
            this.Search1.Size = new System.Drawing.Size(374, 20);
            this.Search1.TabIndex = 6;
            this.Search1.Text = "Введите для поиска";
            this.Search1.TextChanged += new System.EventHandler(this.Search1_TextChanged);
            this.Search1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.maskedTextBox1_MouseDown_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(393, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Фильтрация";
            // 
            // dataGrid1
            // 
            this.dataGrid1.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column13,
            this.ColumnType,
            this.ColumnTitle,
            this.ColumnMIN,
            this.ColumnSupplier,
            this.ColumnInStock});
            this.dataGrid1.Location = new System.Drawing.Point(-2, 50);
            this.dataGrid1.Name = "dataGrid1";
            this.dataGrid1.Size = new System.Drawing.Size(837, 400);
            this.dataGrid1.TabIndex = 0;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Image";
            this.Column13.Name = "Column13";
            this.Column13.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // ColumnType
            // 
            this.ColumnType.HeaderText = "Type";
            this.ColumnType.Name = "ColumnType";
            // 
            // ColumnTitle
            // 
            this.ColumnTitle.HeaderText = "Title";
            this.ColumnTitle.Name = "ColumnTitle";
            // 
            // ColumnMIN
            // 
            this.ColumnMIN.HeaderText = "MinCount";
            this.ColumnMIN.Name = "ColumnMIN";
            // 
            // ColumnSupplier
            // 
            this.ColumnSupplier.HeaderText = "Supplier";
            this.ColumnSupplier.Name = "ColumnSupplier";
            // 
            // ColumnInStock
            // 
            this.ColumnInStock.HeaderText = "CountInStock";
            this.ColumnInStock.Name = "ColumnInStock";
            // 
            // dataSet1
            // 
            this.dataSet1.DataSetName = "DataSet1";
            this.dataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataSet1BindingSource
            // 
            this.dataSet1BindingSource.DataSource = this.dataSet1;
            this.dataSet1BindingSource.Position = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(605, 21);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(217, 23);
            this.button1.TabIndex = 16;
            this.button1.Text = "Добавить материал ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // BolshaiaPacka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 481);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGrid1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Search1);
            this.Controls.Add(this.filtering);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "BolshaiaPacka";
            this.Text = "Большая пачка";
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox filtering;
        private System.Windows.Forms.MaskedTextBox Search1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGrid1;
        private System.Windows.Forms.BindingSource dataSet1BindingSource;
        private DataSet1 dataSet1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSupplier;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnInStock;
        private System.Windows.Forms.Button button1;
    }
}

