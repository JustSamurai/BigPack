﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VisualCaseChempORDEN.Resources;
using static System.Net.Mime.MediaTypeNames;

namespace VisualCaseChempORDEN
{
    public partial class BolshaiaPacka : Form
    {
        public string Strconn;
        public SqlConnection conn;
        string query;
        string filterQuery = null;
        public BolshaiaPacka()
        {
            InitializeComponent();
            Strconn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            conn = new SqlConnection(Strconn);
            
            query = "SELECT Material.[Image], MT.Title, Material.Title, Material.MinCount, Supplier.Title, Material.CountInStock " +
                            "FROM Material JOIN MaterialType as MT " +
                            "ON(Material.MaterialTypeID = MT.ID), " +
                            "Supplier JOIN MaterialSupplier as MS " +
                            "ON(Supplier.ID = MS.SupplierID) " +
                            "WHERE Material.ID = MS.MaterialID " +
                            "ORDER BY MT.Title";
            LoadData(query);
        }

        public void LoadData(string query)
        {
            try
            {
                dataGrid1.Rows.Clear();
                conn.Open();

                SqlCommand command = new SqlCommand(query, conn);
                SqlDataReader reader = command.ExecuteReader();
                List<string[]> data = new List<string[]>();
                
                while (reader.Read())
                {
                    data.Add(new string[6]);

                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[2].ToString();
                    data[data.Count - 1][3] = reader[3].ToString();
                    data[data.Count - 1][4] = reader[4].ToString();
                    data[data.Count - 1][5] = reader[5].ToString();
                }
                reader.Close();
                conn.Close();
                foreach (string[] s in data)
                {
                    dataGrid1.Rows.Add(s);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void maskedTextBox1_MouseDown_1(object sender, MouseEventArgs e)
        {
            Search1.Clear();
        }

        private void filtering_SelectedIndexChanged(object sender, EventArgs e)
        {
            filterQuery = filtering.SelectedItem.ToString();
            query = "SELECT Material.[Image], MT.Title, Material.Title, Material.MinCount, Supplier.Title, Material.CountInStock " +
                            "FROM Material JOIN MaterialType as MT " +
                            "ON(Material.MaterialTypeID = MT.ID), " +
                            "Supplier JOIN MaterialSupplier as MS " +
                            "ON(Supplier.ID = MS.SupplierID) " +
                            "WHERE Material.ID = MS.MaterialID AND MT.Title LIKE '" + filterQuery + "'";
            LoadData(query);
        }

        private void Search1_TextChanged(object sender, EventArgs e)
        {
            query = "SELECT Material.[Image], MT.Title, Material.Title, Material.MinCount, Supplier.Title, Material.CountInStock " +
                            "FROM Material JOIN MaterialType as MT " +
                            "ON(Material.MaterialTypeID = MT.ID), " +
                            "Supplier JOIN MaterialSupplier as MS " +
                            "ON(Supplier.ID = MS.SupplierID) " +
                            "WHERE Material.ID = MS.MaterialID AND " +
                            "Material.Title" + " LIKE '%" + Search1.Text + "%'";
            LoadData(query);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            AddForm addForm = new AddForm();
            addForm.Show();
            this.Hide();
        }
    }
}
